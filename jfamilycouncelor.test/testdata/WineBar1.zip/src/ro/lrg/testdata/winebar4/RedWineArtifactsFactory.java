package ro.lrg.testdata.winebar4;

class RedWineArtifactsFactory implements WineArtifactsFactory {

	public RedWine createWine() {
		return new RedWine();
	}

	public RedWineGlass createWineGlass() {
		return new RedWineGlass();
	}

}
