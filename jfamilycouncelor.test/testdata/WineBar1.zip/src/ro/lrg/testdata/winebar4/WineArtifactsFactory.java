package ro.lrg.testdata.winebar4;

interface WineArtifactsFactory {

	public Wine createWine();

	public WineGlass createWineGlass();

}
