package ro.lrg.testdata.winebar4;

interface WineGlass { }

class RedWineGlass implements WineGlass { }

class WhiteWineGlass implements WineGlass { }
