package ro.lrg.testdata.winebar4;

interface Wine { }

class RedWine implements Wine { }

class WhiteWine implements Wine { }
