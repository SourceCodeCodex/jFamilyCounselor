package ro.lrg.testdata.winebar4;

class WhiteWineArtifactsFactory implements WineArtifactsFactory {

	public WhiteWine createWine() {
		return new WhiteWine();
	}

	public WhiteWineGlass createWineGlass() {
		return new WhiteWineGlass();
	}

}
