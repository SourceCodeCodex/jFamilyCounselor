package ro.lrg.testdata.winebar4;

class WineBar {

	private RedWineArtifactsFactory f1 = new RedWineArtifactsFactory();
	private WhiteWineArtifactsFactory f2 = new WhiteWineArtifactsFactory();
	
	private void doServe(Wine w, WineGlass g) {
		WaiterTray tray = new WaiterTray();
		Wine tmp1 = w;
		WineGlass tmp2 = g; 
		tray.setWine(tmp1);
		tray.setGlass(tmp2);
	}
	
	public void serve() {
		//The declared returned types of the invoked methods
		//represents the single possible runtime types of the
		//corresponding objects because these declared types do 
		//not have any other concrete descendant
		doServe(f1.createWine(), f1.createWineGlass());
		doServe(f2.createWine(), f2.createWineGlass());
	}
}