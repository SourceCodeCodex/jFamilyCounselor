package ro.lrg.testdata.winebar3;

interface WineGlass { }

class RedWineGlass implements WineGlass { }

class WhiteWineGlass implements WineGlass { }
