package ro.lrg.testdata.winebar3;

class WineBar {
	
	private void doServe(Wine w, WineGlass g) {
		WaiterTray wt = new WaiterTray();
		wt.setWine(w);
		wt.setGlass(g);
	}
	
	public void serveWhiteWine(WhiteWine wRed, WhiteWineGlass gRed) {
		//wRed, gRed can be of just one concrete type based on their declared type
		doServe(wRed , gRed);
	}

	public void serveRedWine(RedWine wWhite, RedWineGlass gWhite) {
		//wWhite, gWhite can be of just one concrete type based on their declared type
		doServe(wWhite , gWhite);
	}

}