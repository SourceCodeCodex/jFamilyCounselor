package ro.lrg.testdata.winebar3;

class WaiterTray {
	
	private Wine _wine;
	private WineGlass _glass;
	
	public void setWine(Wine wineP) {
		_wine = wineP;
	}
	
	public void setGlass(WineGlass glassP) {
		_glass = glassP;
	}
			
}
