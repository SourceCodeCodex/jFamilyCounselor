package ro.lrg.testdata.winebar3;

interface Wine { }

class RedWine implements Wine { }

class WhiteWine implements Wine { }
