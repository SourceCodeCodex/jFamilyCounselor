package ro.lrg.testdata.winebar2;

interface Wine { }

class RedWine implements Wine { }

class WhiteWine implements Wine { }
