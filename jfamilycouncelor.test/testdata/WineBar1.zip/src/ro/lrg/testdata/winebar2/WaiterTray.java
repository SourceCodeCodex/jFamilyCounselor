package ro.lrg.testdata.winebar2;

class WaiterTray {
	
	private Wine _wine;
	private WineGlass _glass;
	
	public void setBoth(Wine wineB, WineGlass glassB) {
		_wine = wineB;
		_glass = glassB;
	}
			
}
