package ro.lrg.testdata.winebar2;

interface WineGlass { }

class RedWineGlass implements WineGlass { }

class WhiteWineGlass implements WineGlass { }
