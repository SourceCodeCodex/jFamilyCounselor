package ro.lrg.testdata.winebar2;

class WineBar {
	
	private void doServe(Wine w, WineGlass g) {
		WaiterTray wt1 = new WaiterTray();
		wt1.setBoth(new RedWine(), new RedWineGlass());

		WaiterTray wt2 = new WaiterTray();
		Wine tmp = w;
		wt2.setBoth(tmp, g);
	}
	
	public void serve() {
		doServe(new WhiteWine(), new WhiteWineGlass());
	}
	
}