package ro.lrg.testdata.winebar1;

interface WineGlass { }

class RedWineGlass implements WineGlass { }

class WhiteWineGlass implements WineGlass { }
