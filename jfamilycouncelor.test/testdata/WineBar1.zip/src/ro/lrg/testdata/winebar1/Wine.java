package ro.lrg.testdata.winebar1;

interface Wine { }

class RedWine implements Wine { }

class WhiteWine implements Wine { }
